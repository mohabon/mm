echo "its my first script"
touch testfile
ls
echo "end"
